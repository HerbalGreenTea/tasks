﻿namespace Manipulation
{
    public class Manipulator
    {
        public const float UpperArm = 150;
        public const float Forearm = 120;
        public const float Palm = 60;
    }
}