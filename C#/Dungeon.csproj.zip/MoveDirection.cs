﻿namespace Dungeon
{
	public enum MoveDirection
	{
		Up,
		Down,
		Right,
		Left
	}
}