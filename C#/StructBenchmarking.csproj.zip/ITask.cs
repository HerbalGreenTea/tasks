﻿namespace StructBenchmarking
{
    public interface ITask
    {
        void Run();
    }
}