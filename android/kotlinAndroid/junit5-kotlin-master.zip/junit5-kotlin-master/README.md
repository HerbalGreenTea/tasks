# Examples of usage JUnit 5 written on Kotlin
