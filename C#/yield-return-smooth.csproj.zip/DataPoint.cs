namespace yield
{
	public class DataPoint
	{
		public double X;
		public double OriginalY;
		public double ExpSmoothedY;
		public double AvgSmoothedY;
		public double MaxY;
	}
}